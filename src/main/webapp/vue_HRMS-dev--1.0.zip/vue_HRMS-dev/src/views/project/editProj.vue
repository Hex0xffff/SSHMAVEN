<template>
  <proj-info :is-eidt="true"/>
</template>

<script>
import ProjInfo from './components/projInfo'
export default {
  name: 'EditProj',
  components: {
    ProjInfo
  }
}
</script>
