<template>
  <div id="training-container">
    <header><h1>{{ title }}</h1></header>
  </div>

</template>

<script>
export default {
  name: 'MyPlan',
  data() {
    return {
      title: 'my plan'
    }
  }
}
</script>
