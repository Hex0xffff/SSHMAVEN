<template>
  <div class="dashboard-editor-container">
    <div class=" clearfix">
      <span>you have roles:</span>
      <span v-for="item in roles" :key="item" class="pan-info-roles">{{ item }}</span>
      <div class="info-container">
        <span class="display_name">your name is {{ name }}</span>
        <span style="font-size:20px;padding-top:20px;display:inline-block;">admin's Dashboard</span>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'DashboardAdmin',
  computed: {
    ...mapGetters(['name', 'avatar', 'roles'])
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
  .info-container {
    position: relative;
    margin-left: 190px;
    height: 150px;
    line-height: 200px;
    .display_name {
      font-size: 48px;
      line-height: 48px;
      color: #212121;
      position: absolute;
      top: 25px;
    }
  }
}
</style>
